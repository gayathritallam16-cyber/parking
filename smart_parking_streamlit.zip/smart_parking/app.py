"""Smart Parking Management System - Streamlit app.

Run:  streamlit run app.py
"""
import io
from datetime import timedelta

import pandas as pd
import streamlit as st

import db

try:
    import qrcode
except ImportError:  # QR is optional; app still works without it
    qrcode = None

st.set_page_config(page_title="Smart Parking", page_icon="🅿️", layout="wide")
db.init_db()
db.run_housekeeping()


def qr_png(text):
    if qrcode is None:
        return None
    img = qrcode.make(text)
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return buf.getvalue()


def df(rows):
    return pd.DataFrame(rows)


# ------------------------------------------------------------------ sidebar
st.sidebar.title("🅿️ Smart Parking")
page = st.sidebar.radio(
    "Menu",
    ["Dashboard", "Book a Slot", "My Bookings", "Gate: Entry", "Gate: Exit & Pay",
     "Notifications", "Admin"],
)
demo = st.sidebar.toggle("Demo mode (skip entry-time check)", value=True,
                         help="Lets you test gate entry right after booking.")
st.sidebar.caption(f"Rate: ₹{db.RATE_PER_HOUR}/hr · Overstay: +₹{db.OVERSTAY_RATE}/hr")
if st.sidebar.button("🔄 Refresh"):
    st.rerun()

# ---------------------------------------------------------------- dashboard
if page == "Dashboard":
    st.title("Live Parking Dashboard")
    total, occupied, reserved = db.occupancy_now()
    free = total - len(occupied) - len(reserved)
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Total slots", total)
    c2.metric("Free", free)
    c3.metric("Reserved", len(reserved))
    c4.metric("Occupied", len(occupied))
    st.subheader("Slot map")
    cols = st.columns(5)
    for i in range(1, total + 1):
        icon, label = ("🟢", "Free")
        if i in occupied:
            icon, label = "🔴", "Occupied"
        elif i in reserved:
            icon, label = "🟡", "Reserved"
        cols[(i - 1) % 5].markdown(f"**{icon} Slot {i}**  \n{label}")
    st.caption("🟢 Free · 🟡 Reserved · 🔴 Occupied")

# ------------------------------------------------------------------ booking
elif page == "Book a Slot":
    st.title("Reserve a Parking Slot")
    with st.form("book"):
        c1, c2 = st.columns(2)
        name = c1.text_input("Name")
        phone = c2.text_input("Mobile number")
        plate = c1.text_input("Vehicle number", placeholder="AP07AB1234")
        rfid = c2.text_input("RFID tag (optional)")
        start_off = c1.selectbox("Arrive in", [0, 15, 30, 45, 60],
                                 format_func=lambda m: "Now" if m == 0 else f"{m} minutes")
        hours = c2.slider("Duration (hours)", 1, 8, 2)
        start = db.now() + timedelta(minutes=start_off)
        end = start + timedelta(hours=hours)
        free = db.free_slots(start, end)
        slot = st.selectbox("Slot", free) if free else None
        submit = st.form_submit_button("Confirm booking")
    if not free:
        st.error("No slots available for that window.")
    if submit:
        if not (name and phone and plate) or slot is None:
            st.warning("Name, mobile, vehicle number and a slot are required.")
        else:
            try:
                bid, token = db.create_booking(name, phone.strip(), plate, rfid, slot, start, end)
                st.session_state["last"] = (bid, token)
                st.success(f"Booking #{bid} confirmed for slot {slot}. "
                           f"Estimated fee: ₹{hours * db.RATE_PER_HOUR}")
            except ValueError as e:
                st.error(str(e))
    if "last" in st.session_state:
        bid, token = st.session_state["last"]
        st.subheader("Your entry pass")
        c1, c2 = st.columns([1, 2])
        png = qr_png(token)
        if png:
            c1.image(png, caption=f"Code: {token}", width=200)
            c1.download_button("Download QR", png, f"parking_{bid}.png", "image/png")
        else:
            c1.info(f"Entry code: **{token}**\n\n(Install `qrcode[pil]` to see a QR image.)")
        c2.write(f"Booking ID: **#{bid}**  \nEntry code: **{token}**")
        c2.caption("Show this QR at the gate, or the camera will read your number plate.")

# -------------------------------------------------------------- my bookings
elif page == "My Bookings":
    st.title("My Bookings")
    phone = st.text_input("Enter your mobile number")
    if phone:
        rows = db.bookings_for(phone)
        if not rows:
            st.info("No bookings found.")
        for b in rows:
            with st.expander(f"#{b['booking_id']} · Slot {b['slot_no']} · {b['status']} · {b['start'][5:16]}"):
                st.write(f"Vehicle: **{b['plate']}**  |  {b['start']} → {b['end']}")
                st.write(f"Entry code: `{b['qr_token']}`")
                if b["status"] == "RESERVED" and st.button("Cancel booking", key=f"c{b['booking_id']}"):
                    db.cancel_booking(b["booking_id"])
                    st.rerun()

# ---------------------------------------------------------------- gate entry
elif page == "Gate: Entry":
    st.title("Entry Gate")
    st.caption("Simulates ANPR camera / QR scanner / RFID reader.")
    method = st.radio("Verification method", ["PLATE", "QR", "RFID"], horizontal=True,
                      format_func={"PLATE": "📷 Number plate (ANPR)", "QR": "🔳 QR code",
                                   "RFID": "📡 RFID tag"}.get)
    if method == "PLATE":
        img = st.file_uploader("Upload plate image (optional - OCR hook in app.py)", type=["jpg", "jpeg", "png"])
        if img:
            st.image(img, width=300)
            st.info("To auto-read plates, plug an OCR engine (e.g. EasyOCR / OpenCV) in here "
                    "and pre-fill the text below.")
    value = st.text_input({"PLATE": "Detected plate number", "QR": "Scanned QR code",
                           "RFID": "RFID tag ID"}[method])
    if st.button("Verify & open gate", type="primary"):
        b, reason = db.find_for_entry(method, value, demo)
        if b:
            db.do_entry(b, method)
            st.success(f"✅ Gate OPEN. Welcome {b['name']}! Proceed to slot {b['slot_no']}.")
            st.balloons()
        else:
            st.error(f"⛔ Gate CLOSED. {reason}")
    st.divider()
    st.subheader("Report unauthorized parking")
    c1, c2 = st.columns(2)
    up = c1.text_input("Plate found in slot", key="up")
    us = c2.number_input("Slot number", 1, db.NUM_SLOTS, 1, key="us")
    if st.button("Raise alert"):
        st.warning(db.raise_unauthorized(up, int(us)))

# ------------------------------------------------------------ gate exit/pay
elif page == "Gate: Exit & Pay":
    st.title("Exit Gate & Payment")
    plate = st.text_input("Vehicle number (from ANPR)")
    if plate:
        sess = db.active_session_for_plate(plate)
        if not sess:
            st.error("No active parking session for this vehicle.")
        else:
            fee = db.compute_fee(sess)
            st.write(f"Entered at **{sess['entry_time']}** · Slot **{sess['slot_no']}**")
            c1, c2, c3 = st.columns(3)
            c1.metric("Hours billed", fee["hours"])
            c2.metric("Overstay charge", f"₹{fee['penalty']}")
            c3.metric("Total due", f"₹{fee['total']}")
            method = st.radio("Pay with", ["UPI", "Card", "Wallet"], horizontal=True)
            if st.button("Pay & open exit gate", type="primary"):
                invoice, fee = db.pay_and_exit(sess, method)
                st.success(f"Payment received. Exit gate OPEN. Invoice {invoice}")
                receipt = (
                    f"SMART PARKING RECEIPT\nInvoice: {invoice}\nVehicle: {sess['plate']}\n"
                    f"Slot: {sess['slot_no']}\nEntry: {sess['entry_time']}\nExit: {db.now()}\n"
                    f"Base: Rs {fee['base']}\nOverstay: Rs {fee['penalty']}\n"
                    f"TOTAL: Rs {fee['total']}\nPaid via: {method}\n")
                st.download_button("Download receipt", receipt, f"{invoice}.txt")

# ------------------------------------------------------------ notifications
elif page == "Notifications":
    st.title("Notifications")
    phone = st.text_input("Mobile number")
    if phone:
        rows = db.notifications_for(phone)
        st.dataframe(df(rows), use_container_width=True, hide_index=True) if rows else st.info("Nothing yet.")
    st.caption("Messages are logged as PUSH and SMS. Connect Firebase / Twilio in db.notify() for real delivery.")

# -------------------------------------------------------------------- admin
elif page == "Admin":
    st.title("Admin Console")
    total, occupied, reserved = db.occupancy_now()
    c1, c2, c3 = st.columns(3)
    c1.metric("Revenue", f"₹{db.revenue_total():.0f}")
    c2.metric("Occupancy", f"{len(occupied) / total:.0%}")
    c3.metric("Alerts", len(db.table("alerts")))
    tabs = st.tabs(["Bookings", "Sessions", "Payments", "Alerts", "Notifications"])
    for tab, name in zip(tabs, ["bookings", "sessions", "payments", "alerts", "notifications"]):
        with tab:
            rows = db.table(name)
            st.dataframe(df(rows), use_container_width=True, hide_index=True) if rows else st.info("No data.")
    st.divider()
    if st.button("⚠️ Reset all demo data"):
        db.reset_all()
        st.rerun()
