"""SQLite data layer for the Smart Parking System."""
import sqlite3
import secrets
import math
from datetime import datetime, timedelta

DB_PATH = "parking.db"
NUM_SLOTS = 20
RATE_PER_HOUR = 20      # Rs per hour
OVERSTAY_RATE = 10      # extra Rs per hour beyond booked end
GRACE_MIN = 15          # minutes after start before a reservation expires
EARLY_MIN = 15          # how early a user may enter before start time
FMT = "%Y-%m-%d %H:%M:%S"


def now():
    return datetime.now().replace(microsecond=0)


def conn():
    c = sqlite3.connect(DB_PATH)
    c.row_factory = sqlite3.Row
    return c


def init_db():
    with conn() as c:
        c.executescript(
            """
            CREATE TABLE IF NOT EXISTS slots(
                slot_no INTEGER PRIMARY KEY
            );
            CREATE TABLE IF NOT EXISTS bookings(
                booking_id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT, phone TEXT, plate TEXT, rfid TEXT,
                slot_no INTEGER, start TEXT, end TEXT,
                qr_token TEXT UNIQUE, status TEXT, created_at TEXT
            );
            CREATE TABLE IF NOT EXISTS sessions(
                session_id INTEGER PRIMARY KEY AUTOINCREMENT,
                booking_id INTEGER, plate TEXT, slot_no INTEGER,
                entry_time TEXT, exit_time TEXT, method TEXT,
                amount REAL, paid INTEGER DEFAULT 0
            );
            CREATE TABLE IF NOT EXISTS payments(
                payment_id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id INTEGER, amount REAL, method TEXT,
                invoice_no TEXT, paid_at TEXT
            );
            CREATE TABLE IF NOT EXISTS notifications(
                notif_id INTEGER PRIMARY KEY AUTOINCREMENT,
                booking_id INTEGER, phone TEXT, kind TEXT,
                message TEXT, channel TEXT, sent_at TEXT
            );
            CREATE TABLE IF NOT EXISTS alerts(
                alert_id INTEGER PRIMARY KEY AUTOINCREMENT,
                plate TEXT, slot_no INTEGER, message TEXT, created_at TEXT
            );
            """
        )
        if c.execute("SELECT COUNT(*) FROM slots").fetchone()[0] == 0:
            c.executemany("INSERT INTO slots(slot_no) VALUES(?)",
                          [(i,) for i in range(1, NUM_SLOTS + 1)])


def norm_plate(p):
    return "".join(ch for ch in (p or "").upper() if ch.isalnum())


# ---------- notifications ----------
def notify(booking_id, phone, kind, message):
    with conn() as c:
        for ch in ("PUSH", "SMS"):
            c.execute(
                "INSERT INTO notifications(booking_id,phone,kind,message,channel,sent_at) "
                "VALUES(?,?,?,?,?,?)",
                (booking_id, phone, kind, message, ch, now().strftime(FMT)),
            )


def already_notified(booking_id, kind):
    with conn() as c:
        return c.execute(
            "SELECT 1 FROM notifications WHERE booking_id=? AND kind=? LIMIT 1",
            (booking_id, kind)).fetchone() is not None


# ---------- housekeeping ----------
def run_housekeeping():
    """Expire no-shows, send time-remaining and overstay alerts."""
    t = now()
    with conn() as c:
        rows = c.execute("SELECT * FROM bookings WHERE status IN ('RESERVED','ACTIVE')").fetchall()
    for b in rows:
        start = datetime.strptime(b["start"], FMT)
        end = datetime.strptime(b["end"], FMT)
        if b["status"] == "RESERVED" and t > start + timedelta(minutes=GRACE_MIN):
            with conn() as c:
                c.execute("UPDATE bookings SET status='EXPIRED' WHERE booking_id=?", (b["booking_id"],))
            notify(b["booking_id"], b["phone"], "EXPIRED",
                   f"Booking #{b['booking_id']} expired (no arrival). Slot {b['slot_no']} released.")
        elif b["status"] == "ACTIVE":
            left = (end - t).total_seconds() / 60
            if 0 < left <= 15 and not already_notified(b["booking_id"], "TIME_LEFT"):
                notify(b["booking_id"], b["phone"], "TIME_LEFT",
                       f"Only {int(left)} min left for slot {b['slot_no']}. Extend or exit soon.")
            if left <= 0 and not already_notified(b["booking_id"], "OVERSTAY"):
                notify(b["booking_id"], b["phone"], "OVERSTAY",
                       f"Booked time over for slot {b['slot_no']}. Overstay charges apply.")


# ---------- booking ----------
def free_slots(start, end):
    s, e = start.strftime(FMT), end.strftime(FMT)
    with conn() as c:
        busy = {r[0] for r in c.execute(
            "SELECT slot_no FROM bookings WHERE status IN ('RESERVED','ACTIVE') "
            "AND start < ? AND end > ?", (e, s))}
        allslots = [r[0] for r in c.execute("SELECT slot_no FROM slots ORDER BY slot_no")]
    return [x for x in allslots if x not in busy]


def create_booking(name, phone, plate, rfid, slot_no, start, end):
    if slot_no not in free_slots(start, end):
        raise ValueError("Slot is no longer available for that time window.")
    token = secrets.token_hex(4).upper()
    with conn() as c:
        cur = c.execute(
            "INSERT INTO bookings(name,phone,plate,rfid,slot_no,start,end,qr_token,status,created_at) "
            "VALUES(?,?,?,?,?,?,?,?,?,?)",
            (name, phone, norm_plate(plate), (rfid or "").strip().upper(), slot_no,
             start.strftime(FMT), end.strftime(FMT), token, "RESERVED", now().strftime(FMT)))
        bid = cur.lastrowid
    notify(bid, phone, "CONFIRMED",
           f"Booking #{bid} confirmed: slot {slot_no}, {start:%d %b %H:%M} - {end:%H:%M}. Code {token}.")
    return bid, token


def get_booking(bid):
    with conn() as c:
        return c.execute("SELECT * FROM bookings WHERE booking_id=?", (bid,)).fetchone()


def cancel_booking(bid):
    b = get_booking(bid)
    if b and b["status"] == "RESERVED":
        with conn() as c:
            c.execute("UPDATE bookings SET status='CANCELLED' WHERE booking_id=?", (bid,))
        notify(bid, b["phone"], "CANCELLED", f"Booking #{bid} cancelled.")
        return True
    return False


def bookings_for(phone=None):
    q = "SELECT * FROM bookings"
    args = ()
    if phone:
        q += " WHERE phone=?"
        args = (phone.strip(),)
    with conn() as c:
        return c.execute(q + " ORDER BY booking_id DESC", args).fetchall()


# ---------- gate ----------
def find_for_entry(method, value, demo=False):
    """method: PLATE | QR | RFID. Returns (booking|None, reason)."""
    col = {"PLATE": "plate", "QR": "qr_token", "RFID": "rfid"}[method]
    v = norm_plate(value) if method == "PLATE" else (value or "").strip().upper()
    if not v:
        return None, "Nothing to verify."
    with conn() as c:
        rows = c.execute(
            f"SELECT * FROM bookings WHERE {col}=? AND status='RESERVED' ORDER BY start", (v,)).fetchall()
    if not rows:
        return None, "No active reservation found."
    t = now()
    for b in rows:
        start = datetime.strptime(b["start"], FMT)
        end = datetime.strptime(b["end"], FMT)
        if demo or (start - timedelta(minutes=EARLY_MIN) <= t <= end):
            return b, "OK"
    return None, f"Too early. Entry opens {EARLY_MIN} min before your start time."


def do_entry(b, method):
    with conn() as c:
        c.execute("UPDATE bookings SET status='ACTIVE' WHERE booking_id=?", (b["booking_id"],))
        c.execute(
            "INSERT INTO sessions(booking_id,plate,slot_no,entry_time,method) VALUES(?,?,?,?,?)",
            (b["booking_id"], b["plate"], b["slot_no"], now().strftime(FMT), method))
    notify(b["booking_id"], b["phone"], "ENTRY",
           f"Welcome! Vehicle {b['plate']} entered. Please park in slot {b['slot_no']}.")


def active_session_for_plate(plate):
    with conn() as c:
        return c.execute(
            "SELECT s.*, b.end AS booked_end, b.phone AS phone FROM sessions s "
            "JOIN bookings b ON b.booking_id=s.booking_id "
            "WHERE s.plate=? AND s.exit_time IS NULL ORDER BY s.session_id DESC LIMIT 1",
            (norm_plate(plate),)).fetchone()


def compute_fee(sess, at=None):
    at = at or now()
    entry = datetime.strptime(sess["entry_time"], FMT)
    end = datetime.strptime(sess["booked_end"], FMT)
    hours = max(1, math.ceil((at - entry).total_seconds() / 3600))
    base = hours * RATE_PER_HOUR
    over_h = max(0, math.ceil((at - end).total_seconds() / 3600)) if at > end else 0
    penalty = over_h * OVERSTAY_RATE
    return dict(hours=hours, base=base, overstay_hours=over_h, penalty=penalty, total=base + penalty)


def pay_and_exit(sess, method):
    fee = compute_fee(sess)
    t = now().strftime(FMT)
    invoice = f"INV-{now():%Y%m%d}-{sess['session_id']:05d}"
    with conn() as c:
        c.execute("UPDATE sessions SET exit_time=?, amount=?, paid=1 WHERE session_id=?",
                  (t, fee["total"], sess["session_id"]))
        c.execute("INSERT INTO payments(session_id,amount,method,invoice_no,paid_at) VALUES(?,?,?,?,?)",
                  (sess["session_id"], fee["total"], method, invoice, t))
        c.execute("UPDATE bookings SET status='COMPLETED' WHERE booking_id=?", (sess["booking_id"],))
    notify(sess["booking_id"], sess["phone"], "PAID",
           f"Payment of Rs {fee['total']:.0f} received ({method}). Invoice {invoice}. Thank you!")
    return invoice, fee


def raise_unauthorized(plate, slot_no):
    msg = f"Unauthorized vehicle {norm_plate(plate)} detected at slot {slot_no}."
    with conn() as c:
        c.execute("INSERT INTO alerts(plate,slot_no,message,created_at) VALUES(?,?,?,?)",
                  (norm_plate(plate), slot_no, msg, now().strftime(FMT)))
        owner = c.execute(
            "SELECT * FROM bookings WHERE slot_no=? AND status IN ('RESERVED','ACTIVE') "
            "AND start<=? AND end>=? LIMIT 1",
            (slot_no, now().strftime(FMT), now().strftime(FMT))).fetchone()
    if owner:
        notify(owner["booking_id"], owner["phone"], "UNAUTHORIZED",
               f"Alert: another vehicle ({norm_plate(plate)}) is parked in your slot {slot_no}.")
    return msg


# ---------- queries for dashboard ----------
def occupancy_now():
    t = now().strftime(FMT)
    with conn() as c:
        total = c.execute("SELECT COUNT(*) FROM slots").fetchone()[0]
        occupied = {r[0] for r in c.execute("SELECT slot_no FROM sessions WHERE exit_time IS NULL")}
        reserved = {r[0] for r in c.execute(
            "SELECT slot_no FROM bookings WHERE status='RESERVED' AND end>=?", (t,))}
    return total, occupied, reserved - occupied


def table(name, order="1 DESC"):
    with conn() as c:
        return [dict(r) for r in c.execute(f"SELECT * FROM {name} ORDER BY {order}")]


def notifications_for(phone):
    with conn() as c:
        return [dict(r) for r in c.execute(
            "SELECT sent_at, channel, kind, message FROM notifications WHERE phone=? ORDER BY notif_id DESC",
            (phone.strip(),))]


def revenue_total():
    with conn() as c:
        return c.execute("SELECT COALESCE(SUM(amount),0) FROM payments").fetchone()[0]


def reset_all():
    with conn() as c:
        for t in ("bookings", "sessions", "payments", "notifications", "alerts"):
            c.execute(f"DELETE FROM {t}")
