# Smart Parking Management System (Streamlit)

Features: advance reservation with QR code, automated entry/exit (ANPR plate, QR, RFID - simulated),
session-based billing with digital payment and receipts, push/SMS notification log, admin dashboard.

## Run
```
pip install -r requirements.txt
streamlit run app.py
```

## Demo flow
1. **Book a Slot** -> note the QR / entry code.
2. **Gate: Entry** -> verify by plate, QR code or RFID -> gate opens.
3. **Gate: Exit & Pay** -> enter plate -> pay (UPI/Card/Wallet) -> download receipt.
4. **Notifications** (by mobile) and **Admin** show the full log, revenue and alerts.

## Files
- `app.py` - Streamlit UI
- `db.py`  - SQLite data layer + business rules (fees, expiry, overstay, alerts)

## Making it real
- Plate reading: add OCR (EasyOCR/OpenCV) in the "Gate: Entry" page.
- SMS/push: send via Twilio/Firebase inside `db.notify()`.
- Payments: replace the simulated button with Razorpay/Stripe checkout.
- Gate hardware: trigger a relay via Raspberry Pi/ESP32 where "Gate OPEN" is shown.
